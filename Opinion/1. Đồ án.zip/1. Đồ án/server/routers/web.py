"""Web Dashboard and View Routers (Jinja2 Templates)."""
import os
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, Request, Form, Response, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from server.models.database import get_db
from server.models.user import User
from server.models.child import Child
from server.models.device import Device
from server.models.audit_log import AuditLog
from server.auth.security import (
    verify_password,
    get_password_hash,
    create_jwt_token,
    generate_csrf_token,
    SESSION_COOKIE_EXPIRE_HOURS,
)
from server.auth.dependencies import (
    get_current_user_optional,
    get_current_user,
)
from server.routers.reports import get_child_report

SESSION_COOKIE_NAME = "ogk_session"
CSRF_COOKIE_NAME = "ogk_csrf"

TEMPLATES_DIR = Path(__file__).resolve().parent.parent.parent / "dashboard" / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

web_router = APIRouter(include_in_schema=False)


@web_router.get("/", response_class=HTMLResponse)
def index(request: Request, user: Optional[User] = Depends(get_current_user_optional)):
    if user:
        return RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)


@web_router.get("/login", response_class=HTMLResponse)
def login_page(request: Request, error: Optional[str] = None):
    csrf_token = generate_csrf_token("anon")
    response = templates.TemplateResponse(
        "login.html",
        {"request": request, "csrf_token": csrf_token, "error": error, "current_user": None}
    )
    response.set_cookie(CSRF_COOKIE_NAME, csrf_token, httponly=False, samesite="lax")
    return response


@web_router.post("/login")
def login_submit(
    request: Request,
    response: Response,
    email: str = Form(...),
    password: str = Form(...),
    csrf_token: str = Form(...),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.email == email.lower().strip()).first()
    if not user:
        return login_page(request, error="Tài khoản hoặc mật khẩu không chính xác.")

    # Check lockout
    now = datetime.now(timezone.utc)
    if user.locked_until_utc:
        locked_time = datetime.fromisoformat(user.locked_until_utc.replace("Z", "+00:00"))
        if now < locked_time:
            diff_min = int((locked_time - now).total_seconds() // 60) + 1
            return login_page(request, error=f"Tài khoản đang bị khóa tạm thời. Thử lại sau {diff_min} phút.")

    if not verify_password(password, user.password_hash):
        user.failed_login_count += 1
        if user.failed_login_count >= 5:
            lock_until = now + timedelta(minutes=15)
            user.locked_until_utc = lock_until.isoformat()
            db.commit()
            return login_page(request, error="Đăng nhập sai 5 lần! Tài khoản đã bị khóa 15 phút.")
        db.commit()
        return login_page(request, error="Tài khoản hoặc mật khẩu không chính xác.")

    # Successful login
    user.failed_login_count = 0
    user.locked_until_utc = None
    db.commit()

    token = create_jwt_token(
        data={"sub": user.id, "email": user.email, "role": user.role},
        expires_delta=timedelta(hours=SESSION_COOKIE_EXPIRE_HOURS),
    )
    csrf = generate_csrf_token(user.id)

    redirect_resp = RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    redirect_resp.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=token,
        httponly=True,
        secure=False,
        samesite="lax",
        max_age=12 * 3600,
    )
    redirect_resp.set_cookie(
        key=CSRF_COOKIE_NAME,
        value=csrf,
        httponly=False,
        secure=False,
        samesite="lax",
        max_age=12 * 3600,
    )
    return redirect_resp


@web_router.get("/logout")
def logout():
    resp = RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    resp.delete_cookie(SESSION_COOKIE_NAME)
    resp.delete_cookie(CSRF_COOKIE_NAME)
    return resp


@web_router.get("/dashboard", response_class=HTMLResponse)
def parent_dashboard(
    request: Request,
    child_id: Optional[str] = None,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    children = db.query(Child).filter(Child.parent_id == user.id).all()
    selected_child = None
    devices = []
    report_data = {"total_used_min": 0, "blocked_count": 0, "top_apps": [], "top_domains": []}

    if children:
        if child_id:
            selected_child = next((c for c in children if c.id == child_id), children[0])
        else:
            selected_child = children[0]

        devices = db.query(Device).filter(Device.child_id == selected_child.id).all()
        # Fetch or create default policy
        from server.models.policy import Policy
        from server.services.policy_service import create_default_policy_for_child
        child_policy = db.query(Policy).filter(Policy.child_id == selected_child.id).first()
        if not child_policy:
            child_policy = create_default_policy_for_child(selected_child.id, db)

        # Fetch report summary
        try:
            report_data = get_child_report(selected_child.id, user, db)
        except Exception:
            pass

    csrf_token = generate_csrf_token(user.id if user else "anon")
    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "current_user": user,
            "children": children,
            "selected_child": selected_child,
            "devices": devices,
            "policy": child_policy if selected_child else None,
            "report": report_data,
            "csrf_token": csrf_token,
        }
    )


@web_router.get("/child-view", response_class=HTMLResponse)
def child_transparency_portal(
    request: Request,
    user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    # Fetch report for first child or demo
    report_data = {"total_used_min": 45, "blocked_count": 2, "top_apps": [], "top_domains": []}
    if user:
        child = db.query(Child).filter(Child.parent_id == user.id).first()
        if child:
            try:
                report_data = get_child_report(child.id, user, db)
            except Exception:
                pass

    csrf_token = generate_csrf_token(user.id if user else "anon")
    return templates.TemplateResponse(
        "child_view.html",
        {
            "request": request,
            "current_user": user,
            "report": report_data,
            "csrf_token": csrf_token,
        }
    )


@web_router.get("/audit/view", response_class=HTMLResponse)
def audit_view(
    request: Request,
    user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    logs = db.query(AuditLog).order_by(AuditLog.ts_utc.desc()).limit(50).all()
    csrf_token = generate_csrf_token(user.id if user else "anon")
    return templates.TemplateResponse(
        "audit_log.html",
        {
            "request": request,
            "current_user": user,
            "logs": logs,
            "csrf_token": csrf_token,
        }
    )
