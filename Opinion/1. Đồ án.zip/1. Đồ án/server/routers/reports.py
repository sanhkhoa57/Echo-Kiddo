"""Reporting Router (/api/v1/reports/{child_id}) - Transparent data for Parent & Child."""
from datetime import datetime, timezone, timedelta
from typing import Annotated
from collections import Counter
from fastapi import APIRouter, Depends
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from server.models.database import get_db
from server.models.user import User
from server.models.event import Event
from server.auth.dependencies import (
    get_current_user,
    get_child_for_parent,
)

router = APIRouter(prefix="/api/v1/reports", tags=["Reports"])


@router.get("/{child_id}")
def get_child_report(
    child_id: str,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[Session, Depends(get_db)],
):
    """Generates daily and weekly usage stats, Top 10 apps, Top 10 domains, and block counts."""
    # Anti-IDOR check
    child = get_child_for_parent(child_id, db, current_user)

    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    week_start = (now - timedelta(days=7)).isoformat()

    # Query events for the past 7 days
    events_stmt = (
        select(Event)
        .where(Event.child_id == child.id, Event.ts >= week_start)
        .order_by(Event.ts.desc())
    )
    events = db.scalars(events_stmt).all()

    # Aggregate stats
    app_usage_counter = Counter()
    domain_query_counter = Counter()
    blocked_count = 0
    today_active_sec = 0

    daily_duration = {}  # YYYY-MM-DD -> total_sec
    for i in range(7):
        d = (now - timedelta(days=i)).strftime("%Y-%m-%d")
        daily_duration[d] = 0

    for evt in events:
        evt_date = evt.ts[:10]
        if evt.type in ("app_start", "app_stop", "domain_query"):
            if evt_date in daily_duration:
                daily_duration[evt_date] += evt.duration_sec

        if evt.ts >= today_start:
            today_active_sec += evt.duration_sec

        if evt.type in ("app_start", "app_stop"):
            app_usage_counter[evt.subject] += evt.duration_sec
        elif evt.type == "domain_query":
            domain_query_counter[evt.subject] += 1
        elif evt.type in ("blocked_app", "blocked_domain"):
            blocked_count += 1

    top_apps = [{"subject": k, "duration_sec": v} for k, v in app_usage_counter.most_common(10)]
    top_domains = [{"subject": k, "queries": v} for k, v in domain_query_counter.most_common(10)]

    return {
        "child_id": child.id,
        "display_name": child.display_name,
        "today_active_sec": today_active_sec,
        "today_active_min": round(today_active_sec / 60, 1),
        "total_blocked_events": blocked_count,
        "daily_breakdown": daily_duration,
        "top_10_apps": top_apps,
        "top_10_domains": top_domains,
    }


@router.get("/export/csv")
def export_events_csv(
    child_id: str,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[Session, Depends(get_db)],
):
    """Exports events for child as clean CSV according to strict 7-field schema."""
    import csv
    import io
    from fastapi.responses import Response

    child = get_child_for_parent(child_id, db, current_user)
    events_stmt = (
        select(Event)
        .where(Event.child_id == child.id)
        .order_by(Event.ts.desc())
        .limit(2000)
    )
    events = db.scalars(events_stmt).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ts", "device_id", "child_id", "type", "subject", "duration_sec", "policy_id"])
    for e in events:
        writer.writerow([e.ts, e.device_id, e.child_id, e.type, e.subject, e.duration_sec, e.policy_id])

    return Response(
        content=output.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=ogk_events_{child.id}.csv"}
    )
