"""Tests for Web Dashboard HTML routes and session flows."""
import os
import pytest
from fastapi.testclient import TestClient

from server.main import app
from server.models.database import Base, engine, SessionLocal
from server.models.user import User
from server.models.child import Child
from server.auth.security import (
    get_password_hash,
    create_jwt_token,
    SESSION_COOKIE_EXPIRE_HOURS,
)
from server.routers.web import SESSION_COOKIE_NAME, CSRF_COOKIE_NAME


@pytest.fixture(scope="module")
def web_test_client():
    os.environ["OGK_TESTING"] = "1"
    Base.metadata.create_all(bind=engine)
    client = TestClient(app)

    db = SessionLocal()
    # Seed a test parent user
    parent = db.query(User).filter(User.email == "dashboard_parent@test.com").first()
    if not parent:
        parent = User(
            id="usr_dash_01",
            email="dashboard_parent@test.com",
            password_hash=get_password_hash("ParentPass123!"),
            role="parent",
        )
        db.add(parent)
        db.commit()

        # Seed child
        child = Child(
            id="chd_dash_01",
            parent_id=parent.id,
            display_name="Bé Minh",
            age_group="6-11",
        )
        db.add(child)
        db.commit()

    db.close()
    yield client


def test_login_page_renders(web_test_client):
    resp = web_test_client.get("/login")
    assert resp.status_code == 200
    assert "Đăng Nhập Phụ Huynh" in resp.text
    assert "csrf_token" in resp.text


def test_login_invalid_password(web_test_client):
    resp = web_test_client.post(
        "/login",
        data={
            "email": "dashboard_parent@test.com",
            "password": "WrongPassword123!",
            "csrf_token": "dummy-token",
        },
    )
    assert resp.status_code == 200
    assert "không chính xác" in resp.text


def test_login_success_and_dashboard_access(web_test_client):
    resp = web_test_client.post(
        "/login",
        data={
            "email": "dashboard_parent@test.com",
            "password": "ParentPass123!",
            "csrf_token": "dummy-token",
        },
        follow_redirects=False,
    )
    assert resp.status_code == 302
    assert resp.headers["location"] == "/dashboard"
    cookies = resp.cookies
    assert SESSION_COOKIE_NAME in cookies

    # Access dashboard with cookie
    dash_resp = web_test_client.get("/dashboard", cookies=cookies)
    assert dash_resp.status_code == 200
    assert "Bé Minh" in dash_resp.text
    assert "Lệnh Điều Khiển Khẩn" in dash_resp.text
    assert "Xóa Toàn Bộ Dữ Liệu Con Tôi" in dash_resp.text


def test_child_view_and_audit_log_access(web_test_client):
    # Child view is accessible
    resp = web_test_client.get("/child-view")
    assert resp.status_code == 200
    assert "Góc Minh Bạch Của Em" in resp.text
    assert "KHÔNG chụp màn hình" in resp.text

    # Audit log view is accessible
    resp_audit = web_test_client.get("/audit/view")
    assert resp_audit.status_code == 200
    assert "Nhật Ký Kiểm Toán Công Khai" in resp_audit.text


def test_logout(web_test_client):
    resp = web_test_client.get("/logout", follow_redirects=False)
    assert resp.status_code == 302
    assert resp.headers["location"] == "/login"
