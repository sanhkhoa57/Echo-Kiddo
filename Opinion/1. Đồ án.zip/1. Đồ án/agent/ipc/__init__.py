"""OGK Agent IPC Package."""
