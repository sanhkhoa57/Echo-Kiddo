"""OGK Agent DNS Package."""
