"""Local Async DNS Proxy Server for OGK-Agent (FR-F2-03, FR-F2-05, FR-F2-06, M1, EX-01, EX-02).
Listens on 127.0.0.1:53 (both UDP and TCP) using dnslib + asyncio.
Implements:
1. Port 53 conflict pre-check (EX-01) with process detection
2. DoH Canary & DoH Endpoints blocking (NXDOMAIN)
3. SafeSearch CNAME/A record redirection
4. Blocked domain sinkholing (0.0.0.0)
5. Upstream DNS forwarding (1.1.1.1) with automatic failover to 8.8.8.8 on timeout > 2s (EX-02)
6. In-memory TTL Cache and eTLD+1 event logging
"""
import asyncio
import logging
import socket
import struct
import time
from typing import Optional, Dict, Tuple, Any, List
import psutil
from dnslib import DNSRecord, DNSHeader, QTYPE, RR, A, CNAME, RCODE

from agent.dns.domain_engine import (
    DomainPolicyEngine,
    ACTION_ALLOW,
    ACTION_BLOCK,
    ACTION_SAFESEARCH,
    ACTION_DOH_CANARY,
    normalize_etld_plus_one,
)

logger = logging.getLogger("OGK.DnsProxy")

DEFAULT_PRIMARY_UPSTREAM = "1.1.1.1"
DEFAULT_SECONDARY_UPSTREAM = "8.8.8.8"
DEFAULT_UPSTREAM_PORT = 53


class DnsTtlCache:
    """In-memory DNS response cache with TTL expiration."""

    def __init__(self, maxsize: int = 2048):
        self.maxsize = maxsize
        self._cache: Dict[Tuple[str, int], Tuple[float, bytes]] = {}

    def get(self, qname: str, qtype: int) -> Optional[bytes]:
        key = (qname.lower().rstrip("."), qtype)
        if key in self._cache:
            expire_at, data = self._cache[key]
            if time.time() < expire_at:
                return data
            else:
                del self._cache[key]
        return None

    def put(self, qname: str, qtype: int, data: bytes, ttl: int = 60) -> None:
        if len(self._cache) >= self.maxsize:
            now = time.time()
            expired = [k for k, (exp, _) in self._cache.items() if exp <= now]
            if expired:
                for k in expired:
                    del self._cache[k]
            else:
                self._cache.pop(next(iter(self._cache)))

        expire_at = time.time() + max(5, ttl)
        self._cache[(qname.lower().rstrip("."), qtype)] = (expire_at, data)

    def clear(self) -> None:
        self._cache.clear()


def check_port_53_conflict(host: str = "127.0.0.1", port: int = 53) -> Optional[Dict[str, Any]]:
    """
    Checks if host:port is already occupied by another service (EX-01).
    Returns conflict info dictionary if occupied, or None if port is free.
    """
    conflict_detected = False

    # 1. Test UDP bind
    try:
        sock_u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock_u.bind((host, port))
        sock_u.close()
    except OSError:
        conflict_detected = True

    # 2. Test TCP bind
    if not conflict_detected:
        try:
            sock_t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock_t.bind((host, port))
            sock_t.close()
        except OSError:
            conflict_detected = True

    if not conflict_detected:
        return None

    # Identify process holding port 53 via psutil
    conflict_info = {
        "host": host,
        "port": port,
        "pid": None,
        "process_name": "unknown",
        "details": "Port is already in use by another service."
    }

    try:
        for conn in psutil.net_connections(kind="inet"):
            if conn.laddr and conn.laddr.port == port:
                if host in (conn.laddr.ip, "0.0.0.0", "127.0.0.1"):
                    conflict_info["pid"] = conn.pid
                    if conn.pid:
                        try:
                            proc = psutil.Process(conn.pid)
                            conflict_info["process_name"] = proc.name()
                        except Exception:
                            pass
                    break
    except Exception as e:
        logger.debug("Failed scanning connections for port conflict: %s", e)

    logger.warning(
        "Port conflict detected on %s:%d! Process: %s (PID: %s)",
        host, port, conflict_info["process_name"], conflict_info["pid"]
    )
    return conflict_info


class DnsProxyServer:
    """
    Async Dual-Stack (UDP + TCP) DNS Proxy Server.
    Integrates Suffix Trie domain filtering, SafeSearch, DoH Canary,
    TTL caching, and upstream failover (EX-02).
    """

    def __init__(
        self,
        engine: DomainPolicyEngine,
        host: str = "127.0.0.1",
        port: int = 53,
        event_buffer=None,
        policy_id: str = "default_policy",
        primary_upstream: str = DEFAULT_PRIMARY_UPSTREAM,
        secondary_upstream: str = DEFAULT_SECONDARY_UPSTREAM,
        upstream_port: int = DEFAULT_UPSTREAM_PORT,
    ):
        self.engine = engine
        self.host = host
        self.port = port
        self.event_buffer = event_buffer
        self.policy_id = policy_id
        self.primary_upstream = primary_upstream
        self.secondary_upstream = secondary_upstream
        self.upstream_port = upstream_port

        self.cache = DnsTtlCache()
        self.udp_transport: Optional[asyncio.DatagramTransport] = None
        self.tcp_server: Optional[asyncio.Server] = None
        self.conflict_info: Optional[Dict[str, Any]] = None
        self.is_running: bool = False

    async def start(self) -> bool:
        """
        Starts the DNS Proxy on UDP and TCP.
        Checks for port conflict before binding (EX-01).
        Returns True if successfully started, False if blocked by conflict.
        """
        # Pre-check port conflict (EX-01)
        self.conflict_info = check_port_53_conflict(self.host, self.port)
        if self.conflict_info:
            logger.error(
                "EX-01: Port %d conflict detected! Occupied by '%s' (PID %s). DNS Proxy start aborted.",
                self.port, self.conflict_info["process_name"], self.conflict_info["pid"]
            )
            return False

        loop = asyncio.get_running_loop()

        # 1. Start UDP Datagram Listener
        try:
            self.udp_transport, _ = await loop.create_datagram_endpoint(
                lambda: _DnsDatagramProtocol(self),
                local_addr=(self.host, self.port)
            )
        except Exception as e:
            logger.error("Failed to start UDP DNS Proxy on %s:%d: %s", self.host, self.port, e)
            self.stop()
            return False

        # 2. Start TCP Stream Listener
        try:
            self.tcp_server = await asyncio.start_server(
                self._handle_tcp_connection,
                host=self.host,
                port=self.port
            )
        except Exception as e:
            logger.warning("TCP DNS listener could not start on %s:%d (%s). Operating in UDP-only mode.", self.host, self.port, e)

        self.is_running = True
        logger.info(
            "OGK DNS Proxy started on %s:%d (UDP & TCP). Upstream: %s (Failover: %s)",
            self.host, self.port, self.primary_upstream, self.secondary_upstream
        )
        return True

    def stop(self) -> None:
        """Stops the DNS proxy listeners cleanly."""
        self.is_running = False
        if self.udp_transport:
            try:
                self.udp_transport.close()
            except Exception:
                pass
            self.udp_transport = None

        if self.tcp_server:
            try:
                self.tcp_server.close()
            except Exception:
                pass
            self.tcp_server = None

        logger.info("OGK DNS Proxy stopped.")

    async def process_dns_query(self, raw_data: bytes) -> Optional[bytes]:
        """
        Core DNS query resolution pipeline.
        Returns DNS response wire bytes.
        """
        try:
            request = DNSRecord.parse(raw_data)
        except Exception as e:
            logger.debug("Failed parsing DNS packet: %s", e)
            return None

        qname = str(request.q.qname).rstrip(".")
        qtype = request.q.qtype

        # 1. Evaluate query via DomainPolicyEngine
        action, reason, target = self.engine.evaluate(qname)
        etld_subject = normalize_etld_plus_one(qname)

        # 2. Handle DoH Canary (RFC/Mozilla spec) & DoH Endpoints -> NXDOMAIN
        if action == ACTION_DOH_CANARY:
            reply = DNSRecord(
                DNSHeader(id=request.header.id, qr=1, aa=1, ra=1, rcode=RCODE.NXDOMAIN),
                q=request.q
            )
            return reply.pack()

        # 3. Handle SafeSearch CNAME Redirection (FR-F2-05)
        elif action == ACTION_SAFESEARCH and target:
            reply = DNSRecord(
                DNSHeader(id=request.header.id, qr=1, aa=1, ra=1, rcode=RCODE.NOERROR),
                q=request.q
            )
            reply.add_answer(RR(request.q.qname, QTYPE.CNAME, rdata=CNAME(target), ttl=300))

            # Record domain_query event with eTLD+1
            if self.event_buffer:
                self.event_buffer.record_event(
                    event_type="domain_query",
                    subject=etld_subject,
                    policy_id=self.policy_id,
                    duration_sec=0
                )
            return reply.pack()

        # 4. Handle Blocked Domain -> Sinkhole (0.0.0.0, TTL 60)
        elif action == ACTION_BLOCK:
            reply = DNSRecord(
                DNSHeader(id=request.header.id, qr=1, aa=1, ra=1, rcode=RCODE.NOERROR),
                q=request.q
            )
            reply.add_answer(RR(request.q.qname, QTYPE.A, rdata=A("0.0.0.0"), ttl=60))

            # Record blocked_domain event with eTLD+1
            if self.event_buffer:
                self.event_buffer.record_event(
                    event_type="blocked_domain",
                    subject=etld_subject,
                    policy_id=self.policy_id,
                    duration_sec=0
                )
            return reply.pack()

        # 5. Handle Allowed Domain: Check TTL Cache
        cached = self.cache.get(qname, qtype)
        if cached:
            try:
                resp_record = DNSRecord.parse(cached)
                resp_record.header.id = request.header.id
                return resp_record.pack()
            except Exception:
                pass

        # 6. Cache Miss: Forward upstream with EX-02 failover
        upstream_resp = await self._forward_upstream_with_failover(raw_data)
        if upstream_resp:
            self.cache.put(qname, qtype, upstream_resp, ttl=60)
            if self.event_buffer:
                self.event_buffer.record_event(
                    event_type="domain_query",
                    subject=etld_subject,
                    policy_id=self.policy_id,
                    duration_sec=0
                )
            return upstream_resp

        # 7. Upstream Timeout: Return SERVFAIL
        reply = DNSRecord(
            DNSHeader(id=request.header.id, qr=1, ra=1, rcode=RCODE.SERVFAIL),
            q=request.q
        )
        return reply.pack()

    async def _forward_upstream_with_failover(self, query_data: bytes) -> Optional[bytes]:
        """
        Forwards DNS query to Primary Upstream (1.1.1.1).
        If timeout > 2s (EX-02), automatically fails over to Secondary Upstream (8.8.8.8).
        """
        loop = asyncio.get_running_loop()

        # Attempt 1: Primary upstream
        try:
            resp = await loop.run_in_executor(
                None, self._sync_udp_query, self.primary_upstream, self.upstream_port, query_data, 2.0
            )
            if resp:
                return resp
        except Exception as e:
            logger.debug("Primary upstream %s failed: %s", self.primary_upstream, e)

        # Attempt 2: Secondary failover (EX-02)
        logger.warning(
            "EX-02: Primary upstream (%s) timed out > 2s. Failing over to secondary (%s)...",
            self.primary_upstream, self.secondary_upstream
        )
        try:
            resp = await loop.run_in_executor(
                None, self._sync_udp_query, self.secondary_upstream, self.upstream_port, query_data, 2.0
            )
            if resp:
                logger.info("EX-02: Secondary upstream (%s) succeeded.", self.secondary_upstream)
                return resp
        except Exception as e:
            logger.error("Secondary upstream %s also failed: %s", self.secondary_upstream, e)

        return None

    def _sync_udp_query(self, host: str, port: int, query_data: bytes, timeout: float) -> Optional[bytes]:
        """Synchronous UDP query helper."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        try:
            sock.sendto(query_data, (host, port))
            data, _ = sock.recvfrom(4096)
            return data
        finally:
            sock.close()

    async def _handle_tcp_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        """Handles DNS over TCP queries (RFC 1035: 2-byte big-endian length prefix)."""
        try:
            while True:
                prefix = await reader.readexactly(2)
                if not prefix:
                    break
                msg_len = struct.unpack("!H", prefix)[0]
                if msg_len > 65535:
                    break
                raw_query = await reader.readexactly(msg_len)

                resp_bytes = await self.process_dns_query(raw_query)
                if resp_bytes:
                    writer.write(struct.pack("!H", len(resp_bytes)) + resp_bytes)
                    await writer.drain()
        except asyncio.IncompleteReadError:
            pass
        except Exception as e:
            logger.debug("TCP client handling error: %s", e)
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass


class _DnsDatagramProtocol(asyncio.DatagramProtocol):
    """Internal Datagram Protocol for DNS Proxy."""

    def __init__(self, server: DnsProxyServer):
        self.server = server
        self.transport: Optional[asyncio.DatagramTransport] = None

    def connection_made(self, transport: asyncio.DatagramTransport) -> None:
        self.transport = transport

    def datagram_received(self, data: bytes, addr: Tuple[str, int]) -> None:
        asyncio.create_task(self._handle_datagram(data, addr))

    async def _handle_datagram(self, data: bytes, addr: Tuple[str, int]) -> None:
        try:
            resp = await self.server.process_dns_query(data)
            if resp and self.transport:
                self.transport.sendto(resp, addr)
        except Exception as e:
            logger.debug("Error responding to %s: %s", addr, e)
