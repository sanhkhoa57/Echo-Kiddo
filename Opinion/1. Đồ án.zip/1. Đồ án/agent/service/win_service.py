"""Windows Service Host for OGK-Agent (FR-F5-09, Section 2 & 3.2).
Runs in Session 0 as LocalSystem. Manages lifecycle of DNS Proxy, App Controller,
Screen Time Engine, IPC Pipe Server, Network/Browser Guards, and Session Launcher.
Supports both SCM Windows Service execution and standalone runner mode.
"""
import asyncio
import logging
import os
import sys
import threading
import time
from typing import Optional

from agent.core.agent_db import AgentDatabase, DEFAULT_AGENT_DB_PATH
from agent.core.event_buffer import EventBuffer
from agent.core.screen_time import ScreenTimeManager
from agent.core.app_controller import AppController
from agent.dns.domain_engine import DomainPolicyEngine
from agent.dns.dns_proxy import DnsProxyServer
from agent.platform.network_guard import NetworkDnsGuard
from agent.platform.browser_policy import BrowserPolicyGuard
from agent.platform.bypass_detector import BypassDetector
from agent.ipc.pipe_protocol import IpcPipeHandler, IpcEnvelope, IpcServer
from agent.service.session_launcher import SessionAgentLauncher
from agent.sync.server_client import AgentServerClient

logger = logging.getLogger("OGK.WinService")

_IS_WINDOWS = sys.platform == "win32"
if _IS_WINDOWS:
    try:
        import win32serviceutil
        import win32service
        import win32event
        import servicemanager
    except ImportError:
        pass


class OGKServiceCore:
    """Core daemon managing all agent subcomponents and life-cycle."""

    def __init__(self, db_path: str = DEFAULT_AGENT_DB_PATH, server_url: str = "http://127.0.0.1:8000"):
        self.db = AgentDatabase(db_path)
        self.server_url = server_url
        self.running = False

        # Core subsystems
        self.event_buffer = EventBuffer(db=self.db)
        self.screen_time_mgr = ScreenTimeManager(db=self.db)
        self.app_controller = AppController(event_buffer=self.event_buffer)
        self.domain_engine = DomainPolicyEngine()
        self.dns_proxy = DnsProxyServer(engine=self.domain_engine, host="127.0.0.1", port=53, event_buffer=self.event_buffer)
        self.net_guard = NetworkDnsGuard(db=self.db)
        self.browser_guard = BrowserPolicyGuard(db=self.db)
        self.bypass_detector = BypassDetector(event_buffer=self.event_buffer)

        # Server sync client
        self.server_client = AgentServerClient(
            server_url=self.server_url,
            event_buffer=self.event_buffer,
            screen_time_mgr=self.screen_time_mgr,
            app_controller=self.app_controller,
            domain_engine=self.domain_engine,
            db=self.db,
        )

        # Session launcher (enforcing No-Stealth-Mode)
        self.session_launcher = SessionAgentLauncher(
            on_unprotected_halt_callback=self._handle_unprotected_halt
        )

        # IPC Handler & Server
        self.ipc_handler = IpcPipeHandler(
            get_status_fn=self._get_session_status,
            on_request_more_time_fn=self._handle_request_more_time,
            verify_pin_fn=self._verify_parent_pin,
            on_tray_ready_fn=self.session_launcher.mark_tray_ready,
        )
        self.ipc_server = IpcServer(self.ipc_handler)

        self._dns_task: Optional[asyncio.Task] = None
        self._async_loop: Optional[asyncio.AbstractEventLoop] = None

    def _get_session_status(self) -> dict:
        """Returns session status for OGK-Tray display."""
        policy = self.server_client.active_policy
        remaining_sec = self.screen_time_mgr.get_remaining_seconds(policy)
        is_locked, reason, warning = self.screen_time_mgr.evaluate_lock_status(policy)
        return {
            "used_total_sec": self.screen_time_mgr.used_total_sec,
            "remaining_sec": max(0, remaining_sec),
            "is_locked": is_locked,
            "lock_reason": reason,
            "warning": warning,
            "is_parent_paused": self.screen_time_mgr.is_parent_paused(),
            "unprotected_halt": self.session_launcher.is_unprotected_halt,
        }

    def _handle_request_more_time(self, minutes: int) -> dict:
        """Records unlock_request event to send to parent dashboard."""
        self.event_buffer.record_event(
            event_type="unlock_request",
            subject=f"request_{minutes}m",
            policy_id=str(self.server_client.current_policy_version),
            duration_sec=minutes * 60,
        )
        return {"status": "REQUESTED", "minutes": minutes}

    def _verify_parent_pin(self, pin: str) -> bool:
        """Verifies parent offline PIN."""
        cached = self.db.get_cached_policy()
        if cached and cached.get("policy"):
            expected_pin = cached["policy"].get("offline_pin", "1234")
            import hmac
            return hmac.compare_digest(expected_pin, pin)
        return pin == "1234"

    def _handle_unprotected_halt(self) -> None:
        """Invoked when Tray UI cannot be displayed after 3 attempts (FR-F5-09)."""
        logger.critical("UNPROTECTED_HALT active: Halting blocking and locking to prevent stealth monitoring.")
        # Restore DNS to avoid bricking internet for kid while halted
        self.net_guard.restore_original_dns()
        # Clear manual locks
        self.screen_time_mgr.set_manual_lock(False)

    def start(self) -> None:
        """Initializes subsystems and starts loops."""
        logger.info("Starting OGK Service Core...")
        self.running = True

        # 1. System Snapshots
        self.net_guard.capture_and_save_snapshot()
        self.browser_guard.capture_and_save_snapshot()

        # 2. Enforce Browser DoH disable
        self.browser_guard.enforce_disable_doh()

        # 3. Check port 53 conflict before locking DNS to 127.0.0.1 (EX-01)
        from agent.dns.dns_proxy import check_port_53_conflict
        conflict = check_port_53_conflict()
        if conflict:
            logger.error("EX-01: Port 53 conflict detected with '%s' (PID %s). Aborting DNS lock to 127.0.0.1.", conflict["process_name"], conflict["pid"])
        else:
            self.net_guard.lock_dns_to_loopback()

        # 4. Start IPC Pipe Server
        self.ipc_server.start()

        # 5. Start background async loop for DNS Proxy & Sync Client
        threading.Thread(target=self._run_async_worker, daemon=True).start()

        # 6. Start synchronous monitoring loop (Process scanner, Screen time tick, Session check)
        threading.Thread(target=self._run_monitoring_loop, daemon=True).start()

    def _run_async_worker(self) -> None:
        """Runs the asyncio loop for DNS Proxy, Heartbeat, and WebSocket."""
        self._async_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._async_loop)

        async def _main_async():
            # Start DNS Proxy
            await self.dns_proxy.start()
            # Start Server Client
            await self.server_client.start()
            # Keep loop active
            while self.running:
                await asyncio.sleep(1.0)
            self.dns_proxy.stop()
            self.server_client.stop()

        self._async_loop.run_until_complete(_main_async())

    def _run_monitoring_loop(self) -> None:
        """Runs periodic checks: 1s screen time tick, 2s process scan, 3s session launcher."""
        last_scan_time = 0.0
        last_launcher_time = 0.0
        last_tamper_check_time = 0.0

        while self.running:
            try:
                now = time.time()

                # If UNPROTECTED_HALT is active, do not enforce limits
                if self.session_launcher.is_unprotected_halt:
                    time.sleep(1.0)
                    continue

                # 1. Tick screen time (every ~1s)
                self.screen_time_mgr.tick()

                # 2. Check lock status
                policy = self.server_client.active_policy
                is_locked, reason, warning = self.screen_time_mgr.evaluate_lock_status(policy)

                # 3. Process scan & enforcement (every 2s)
                if now - last_scan_time >= 2.0:
                    last_scan_time = now
                    app_rules = policy.get("app_rules", [])
                    cat_quotas = policy.get("category_quotas", {})
                    self.app_controller.scan_and_enforce(
                        app_rules=app_rules,
                        category_quotas=cat_quotas,
                        category_used=self.screen_time_mgr.category_used_sec,
                        is_locked=is_locked,
                        policy_id=str(self.server_client.current_policy_version)
                    )

                # 4. Session launcher check (every 3s)
                if now - last_launcher_time >= 3.0:
                    last_launcher_time = now
                    self.session_launcher.trigger_launch_if_needed()

                # 5. Anti-tamper DNS check (every 10s)
                if now - last_tamper_check_time >= 10.0:
                    last_tamper_check_time = now
                    self.net_guard.check_and_enforce_anti_tamper()

                time.sleep(1.0)
            except Exception as e:
                logger.error("Error in service monitoring loop: %s", e)
                time.sleep(1.0)

    def stop(self) -> None:
        """Clean shutdown and rollback."""
        logger.info("Stopping OGK Service Core...")
        self.running = False

        # Stop IPC server
        if hasattr(self, "ipc_server") and self.ipc_server:
            self.ipc_server.stop()

        # Clean rollback: restore original DNS and browser policies
        self.net_guard.restore_original_dns()
        self.browser_guard.restore_browser_policies()
        logger.info("OGK Service Core safely stopped and system restored.")


if _IS_WINDOWS and "win32serviceutil" in sys.modules:
    class OGKWindowsService(win32serviceutil.ServiceFramework):
        _svc_name_ = "OGKService"
        _svc_display_name_ = "Open Guardian for Kids Service"
        _svc_description_ = "Open Guardian for Kids Platform Service (Background Monitoring & Policy Engine)"

        def __init__(self, args):
            win32serviceutil.ServiceFramework.__init__(self, args)
            self.stop_event = win32event.CreateEvent(None, 0, 0, None)
            self.core = OGKServiceCore()

        def SvcStop(self):
            self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
            win32event.SetEvent(self.stop_event)
            self.core.stop()

        def SvcDoRun(self):
            servicemanager.LogMsg(
                servicemanager.EVENTLOG_INFORMATION_TYPE,
                servicemanager.PYS_SERVICE_STARTED,
                (self._svc_name_, "")
            )
            self.core.start()
            win32event.WaitForSingleObject(self.stop_event, win32event.INFINITE)


def configure_scm_recovery(service_name: str = "OGKService") -> bool:
    """Configures Windows SCM recovery actions (restart service after 1 minute on crash)."""
    if not _IS_WINDOWS:
        return False
    try:
        import subprocess
        cmd = ["sc.exe", "failure", service_name, "reset=", "86400", "actions=", "restart/60000/restart/60000/restart/60000"]
        res = subprocess.run(cmd, capture_output=True, text=True, check=False)
        logger.info("SCM recovery configuration for %s: %s", service_name, res.stdout.strip())
        return res.returncode == 0
    except Exception as e:
        logger.warning("Could not configure SCM recovery: %s", e)
        return False


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "run":
        # Standalone runner for testing or dev mode
        core = OGKServiceCore()
        core.start()
        try:
            while True:
                time.sleep(1.0)
        except KeyboardInterrupt:
            core.stop()
    elif _IS_WINDOWS and "win32serviceutil" in sys.modules:
        win32serviceutil.HandleCommandLine(OGKWindowsService)
        if len(sys.argv) > 1 and sys.argv[1] == "install":
            configure_scm_recovery("OGKService")
    else:
        print("Usage: python win_service.py run")


if __name__ == "__main__":
    main()
