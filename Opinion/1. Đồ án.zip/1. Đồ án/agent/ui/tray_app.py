"""OGK-Tray Application (FR-F1-04, FR-F2-02, FR-F3-03, FR-F3-07, FR-F5-09).
Provides the System Tray Icon (pystray) and Tkinter transparency / warning dialogs:
- Countdown timer for remaining screen time today
- 10m / 5m / 1m advance warning popups
- 60-second grace countdown dialog (ViolationCountdownWindow)
- 'What I used today' (Transparency Screen)
- 'Request more time' dialog
- 20-20-20 Eye break reminder cards
- Blocked app / website notification dialogs
"""
import logging
import os
import sys
import threading
import time
from datetime import datetime, timezone
from typing import Optional, Dict, Any, Callable
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageDraw

from agent.ipc.pipe_protocol import IpcEnvelope

logger = logging.getLogger("OGK.TrayApp")


def create_tray_icon_image(state: str = "active") -> Image.Image:
    """Generates a dynamic 64x64 RGBA icon based on protection state."""
    img = Image.new("RGBA", (64, 64), color=(0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    colors = {
        "active": (46, 125, 50, 255),    # Forest green
        "warning": (245, 124, 0, 255),   # Orange
        "locked": (198, 40, 40, 255),    # Red
        "paused": (21, 101, 192, 255),   # Blue
    }
    fill_color = colors.get(state, (46, 125, 50, 255))

    # Draw rounded shield / circle
    draw.ellipse([4, 4, 60, 60], fill=fill_color, outline=(255, 255, 255, 220), width=3)

    if state == "active":
        # Draw white checkmark
        draw.line([20, 32, 28, 42], fill=(255, 255, 255, 255), width=4)
        draw.line([28, 42, 45, 22], fill=(255, 255, 255, 255), width=4)
    elif state == "locked":
        # Draw white lock body
        draw.rectangle([22, 28, 42, 46], fill=(255, 255, 255, 255))
        draw.arc([24, 18, 40, 32], start=180, end=0, fill=(255, 255, 255, 255), width=3)
    elif state == "warning":
        # Draw exclamation mark
        draw.line([32, 20, 32, 36], fill=(255, 255, 255, 255), width=4)
        draw.ellipse([30, 41, 34, 45], fill=(255, 255, 255, 255))
    elif state == "paused":
        # Draw pause bars
        draw.rectangle([22, 22, 27, 42], fill=(255, 255, 255, 255))
        draw.rectangle([37, 22, 42, 42], fill=(255, 255, 255, 255))

    return img


class TrayApplication:
    """Manages the Tray Icon, Background IPC sync, and Tkinter UI Dialogs."""

    def __init__(self, ipc_client=None, headless: bool = False):
        self.ipc_client = ipc_client
        self.headless = headless
        self.running = False
        self.tray_icon = None

        # State cache from service
        self.remaining_sec: int = 3600
        self.used_total_sec: int = 0
        self.is_locked: bool = False
        self.is_parent_paused: bool = False
        self.last_warning_shown: Optional[str] = None
        self.grace_window_open: bool = False

        # Eye rest tracking (20-20-20 rule)
        self.last_eye_break_time: float = time.time()

    def send_tray_ready(self) -> None:
        """Sends TRAY_READY envelope to service to confirm icon is visible."""
        if self.ipc_client:
            try:
                env = IpcEnvelope(msg_type="TRAY_READY")
                self.ipc_client.send_envelope(env)
                logger.info("Sent TRAY_READY to OGK-Service.")
            except Exception as e:
                logger.debug("Failed sending TRAY_READY: %s", e)

    def request_more_time(self, minutes: int = 15) -> None:
        """Sends REQUEST_MORE_TIME to parent via service."""
        if self.ipc_client:
            try:
                env = IpcEnvelope(msg_type="REQUEST_MORE_TIME", payload={"minutes": minutes})
                self.ipc_client.send_envelope(env)
            except Exception as e:
                logger.error("Failed requesting more time: %s", e)

    def show_warning_dialog(self, title: str, message: str) -> None:
        """Displays friendly non-intrusive warning dialog."""
        if self.headless:
            logger.info("[HEADLESS WARNING] %s: %s", title, message)
            return

        def _popup():
            root = tk.Tk()
            root.title(title)
            root.geometry("420x200")
            root.attributes("-topmost", True)
            root.configure(bg="#f5f7fa")

            lbl_title = tk.Label(root, text=title, font=("Segoe UI", 12, "bold"), fg="#d32f2f", bg="#f5f7fa")
            lbl_title.pack(pady=12)

            lbl_msg = tk.Label(root, text=message, font=("Segoe UI", 10), wraplength=380, bg="#f5f7fa")
            lbl_msg.pack(pady=8)

            btn = ttk.Button(root, text="Em đã hiểu", command=root.destroy)
            btn.pack(pady=16)

            root.mainloop()

        threading.Thread(target=_popup, daemon=True).start()

    def show_grace_countdown_dialog(self) -> None:
        """Displays the 60-second ViolationCountdownWindow (FR-F1-04)."""
        if self.headless:
            logger.info("[HEADLESS GRACE WINDOW] 60s countdown started")
            return

        if self.grace_window_open:
            return
        self.grace_window_open = True

        def _countdown():
            root = tk.Tk()
            root.title("OGK - Hết giờ sử dụng")
            root.geometry("460x280")
            root.attributes("-topmost", True)
            root.configure(bg="#fff3e0")

            lbl_header = tk.Label(
                root, text="⏰ Đã hết thời gian sử dụng hôm nay!",
                font=("Segoe UI", 13, "bold"), fg="#e65100", bg="#fff3e0"
            )
            lbl_header.pack(pady=14)

            lbl_desc = tk.Label(
                root,
                text="Em có 60 giây ân hạn để lưu lại bài tập hoặc bấm 'Xin thêm giờ' trước khi máy tính khóa màn hình.",
                font=("Segoe UI", 10), wraplength=400, bg="#fff3e0"
            )
            lbl_desc.pack(pady=6)

            countdown_var = tk.StringVar(value="Thời gian còn lại: 60 giây")
            lbl_timer = tk.Label(
                root, textvariable=countdown_var,
                font=("Segoe UI", 14, "bold"), fg="#bf360c", bg="#fff3e0"
            )
            lbl_timer.pack(pady=12)

            btn_frame = tk.Frame(root, bg="#fff3e0")
            btn_frame.pack(pady=10)

            def _on_req():
                self.request_more_time(15)
                messagebox.showinfo("Đã gửi yêu cầu", "Yêu cầu xin thêm 15 phút đã được gửi tới bố mẹ!", parent=root)
                root.destroy()
                self.grace_window_open = False

            def _on_done():
                root.destroy()
                self.grace_window_open = False

            def _on_parent_pin():
                # Prompt parent PIN dialog
                pin_win = tk.Toplevel(root)
                pin_win.title("Xác thực phụ huynh")
                pin_win.geometry("320x160")
                pin_win.attributes("-topmost", True)
                pin_win.configure(bg="#f5f7fa")

                tk.Label(pin_win, text="Nhập mã PIN / Mật khẩu phụ huynh:", font=("Segoe UI", 9, "bold"), bg="#f5f7fa").pack(pady=10)
                pin_entry = tk.Entry(pin_win, show="*", font=("Segoe UI", 12), justify="center", width=15)
                pin_entry.pack(pady=5)
                pin_entry.focus()

                def _verify():
                    entered = pin_entry.get().strip()
                    if not entered:
                        return
                    authorized = False
                    if self.ipc_client:
                        try:
                            # 1. Get challenge
                            req_c = IpcEnvelope(msg_type="GET_CHALLENGE")
                            resp_c = self.ipc_client.send_envelope(req_c) if hasattr(self.ipc_client, "send_envelope") else self.ipc_client.send_request(req_c)
                            token = resp_c.payload.get("challenge_token") if resp_c else None

                            # 2. Verify PIN
                            req_v = IpcEnvelope(
                                msg_type="VERIFY_PARENT_PIN",
                                challenge_token=token,
                                payload={"pin": entered}
                            )
                            resp_v = self.ipc_client.send_envelope(req_v) if hasattr(self.ipc_client, "send_envelope") else self.ipc_client.send_request(req_v)
                            if resp_v and resp_v.payload.get("valid"):
                                authorized = True
                        except Exception as e:
                            logger.error("IPC PIN verification error: %s", e)
                    else:
                        authorized = (entered == "1234")

                    if authorized:
                        messagebox.showinfo("Mở khóa thành công", "Mã PIN chính xác. Đã mở khóa phiên sử dụng!", parent=pin_win)
                        pin_win.destroy()
                        root.destroy()
                        self.grace_window_open = False
                    else:
                        messagebox.showerror("Sai mã PIN", "Mã PIN phụ huynh không đúng!", parent=pin_win)

                tk.Button(pin_win, text="Xác nhận", font=("Segoe UI", 9, "bold"), bg="#1565c0", fg="white", command=_verify).pack(pady=10)

            btn_req = tk.Button(
                btn_frame, text="🙋 Xin thêm 15 phút",
                font=("Segoe UI", 9, "bold"), bg="#ff9800", fg="white",
                padx=8, pady=4, command=_on_req
            )
            btn_req.pack(side="left", padx=4)

            btn_pin = tk.Button(
                btn_frame, text="🔑 Bố mẹ mở khóa",
                font=("Segoe UI", 9), bg="#1565c0", fg="white",
                padx=8, pady=4, command=_on_parent_pin
            )
            btn_pin.pack(side="left", padx=4)

            btn_ok = tk.Button(
                btn_frame, text="💾 Đã lưu xong",
                font=("Segoe UI", 9), bg="#4caf50", fg="white",
                padx=8, pady=4, command=_on_done
            )
            btn_ok.pack(side="left", padx=4)

            # Countdown ticker
            remaining = [60]
            def _tick():
                if remaining[0] > 0:
                    remaining[0] -= 1
                    countdown_var.set(f"Thời gian còn lại: {remaining[0]} giây")
                    root.after(1000, _tick)
                else:
                    root.destroy()
                    self.grace_window_open = False

            root.after(1000, _tick)
            root.mainloop()

        threading.Thread(target=_countdown, daemon=True).start()

    def show_transparency_screen(self) -> None:
        """Displays 'Hôm nay em đã dùng gì' transparency screen (FR-F3-03)."""
        if self.headless:
            logger.info("[HEADLESS TRANSPARENCY SCREEN] Displaying child usage")
            return

        def _screen():
            root = tk.Toplevel() if tk._default_root else tk.Tk()
            root.title("OGK - Hôm nay em đã dùng gì?")
            root.geometry("520x420")
            root.configure(bg="#ffffff")

            lbl_title = tk.Label(
                root, text="🌟 Hôm nay em đã dùng máy tính như thế nào?",
                font=("Segoe UI", 13, "bold"), fg="#1565c0", bg="#ffffff"
            )
            lbl_title.pack(pady=14)

            # Summary frame
            frame_summary = tk.Frame(root, bg="#e3f2fd", padx=16, pady=12)
            frame_summary.pack(fill="x", padx=20, pady=8)

            used_min = self.used_total_sec // 60
            remain_min = self.remaining_sec // 60
            tk.Label(
                frame_summary,
                text=f"⏱️ Tổng thời gian đã dùng: {used_min} phút  |  Còn lại: {remain_min} phút",
                font=("Segoe UI", 10, "bold"), fg="#0d47a1", bg="#e3f2fd"
            ).pack()

            # Transparency explanation
            tk.Label(
                root,
                text="OGK là người bạn đồng hành minh bạch. Bố mẹ và em cùng xem chung dữ liệu này. "
                     "Hệ thống KHÔNG chụp ảnh màn hình và KHÔNG đọc trộm tin nhắn của em.",
                font=("Segoe UI", 9, "italic"), fg="#555555", bg="#ffffff", wraplength=480
            ).pack(pady=10)

            # Close button
            btn_close = ttk.Button(root, text="Đóng", command=root.destroy)
            btn_close.pack(pady=14)

            root.mainloop()

        threading.Thread(target=_screen, daemon=True).start()

    def show_block_explanation(self, subject: str, reason: str) -> None:
        """Displays friendly explanation when an app or website is blocked (FR-F2-02)."""
        if self.headless:
            logger.info("[HEADLESS BLOCK NOTIFICATION] Blocked %s: %s", subject, reason)
            return

        def _popup():
            root = tk.Tk()
            root.title("OGK - Thông báo an toàn")
            root.geometry("440x220")
            root.attributes("-topmost", True)
            root.configure(bg="#fff5f5")

            lbl_title = tk.Label(
                root, text="🛡️ Ứng dụng / Trang web bị hạn chế",
                font=("Segoe UI", 12, "bold"), fg="#c62828", bg="#fff5f5"
            )
            lbl_title.pack(pady=12)

            msg = f"'{subject}' chưa phù hợp với khung giờ hoặc lứa tuổi của em.\n\nLý do: {reason}"
            lbl_msg = tk.Label(root, text=msg, font=("Segoe UI", 10), wraplength=400, bg="#fff5f5")
            lbl_msg.pack(pady=8)

            btn = ttk.Button(root, text="Em đã hiểu", command=root.destroy)
            btn.pack(pady=16)

            root.mainloop()

        threading.Thread(target=_popup, daemon=True).start()

    def show_eye_break_reminder(self) -> None:
        """Displays 20-20-20 eye rest reminder card (FR-F3-07)."""
        if self.headless:
            logger.info("[HEADLESS EYE BREAK] 20-20-20 eye break reminder")
            return

        def _popup():
            root = tk.Tk()
            root.title("OGK - Nhắc nhở nghỉ mắt")
            root.geometry("400x180")
            root.attributes("-topmost", True)
            root.configure(bg="#e8f5e9")

            tk.Label(
                root, text="👀 Quy tắc 20-20-20: Bảo vệ thị lực!",
                font=("Segoe UI", 12, "bold"), fg="#2e7d32", bg="#e8f5e9"
            ).pack(pady=10)

            tk.Label(
                root,
                text="Em đã dùng máy tính 20 phút liên tục.\nHãy phóng tầm mắt nhìn xa 6 mét trong 20 giây để mắt được thư giãn nhé!",
                font=("Segoe UI", 10), wraplength=360, bg="#e8f5e9"
            ).pack(pady=6)

            ttk.Button(root, text="Em đang nghỉ mắt nè", command=root.destroy).pack(pady=12)
            root.mainloop()

        threading.Thread(target=_popup, daemon=True).start()

    def start_background_loop(self) -> None:
        """Background thread checking status from service, warnings, and eye breaks."""
        self.running = True
        self.send_tray_ready()

        while self.running:
            try:
                # 1. Check eye break (every 20 minutes / 1200s)
                now = time.time()
                if now - self.last_eye_break_time >= 1200:
                    self.last_eye_break_time = now
                    self.show_eye_break_reminder()

                time.sleep(2.0)
            except Exception as e:
                logger.error("Error in tray background loop: %s", e)
                time.sleep(2.0)


def main():
    app = TrayApplication(headless=False)
    # Start background loop
    threading.Thread(target=app.start_background_loop, daemon=True).start()

    # Try starting pystray if available
    try:
        import pystray
        icon_img = create_tray_icon_image("active")
        menu = pystray.Menu(
            pystray.MenuItem("🌟 Hôm nay em đã dùng gì?", lambda: app.show_transparency_screen()),
            pystray.MenuItem("🙋 Xin thêm giờ", lambda: app.request_more_time(15)),
            pystray.MenuItem("👀 Nghỉ mắt 20-20-20", lambda: app.show_eye_break_reminder()),
        )
        icon = pystray.Icon("OGK-Tray", icon_img, "Open Guardian for Kids", menu)
        app.tray_icon = icon
        icon.run()
    except Exception as e:
        logger.info("Pystray not running in GUI mode (%s), running fallback loop.", e)
        try:
            while True:
                time.sleep(1.0)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
