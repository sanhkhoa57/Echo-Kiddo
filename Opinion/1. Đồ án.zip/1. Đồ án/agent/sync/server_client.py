"""Server Sync Client for OGK-Agent (FR-LC-01, FR-LC-02, FR-LC-03, FR-LC-04, Section 5).
Manages Enrollment, 60s Heartbeat, Event Batch Upload, Policy Sync, and WebSocket Urgent Command Hub.
"""
import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any, Callable
import httpx
import websockets

from agent.core.policy_verifier import verify_policy

logger = logging.getLogger("OGK.ServerClient")


class AgentServerClient:
    """Manages all communications between OGK-Agent and OGK-Server."""

    def __init__(
        self,
        server_url: str,
        device_id: str = "",
        child_id: str = "",
        access_token: str = "",
        refresh_token: str = "",
        device_secret: str = "ogk-agent-default-secret",
        pinned_cert_fingerprint: Optional[str] = None,
        event_buffer=None,
        screen_time_mgr=None,
        app_controller=None,
        domain_engine=None,
        db=None,
        http_client: Optional[httpx.AsyncClient] = None,
    ):
        self.server_url = server_url.rstrip("/")
        self.device_id = device_id
        self.child_id = child_id
        self.access_token = access_token
        self.refresh_token = refresh_token
        self.device_secret = device_secret
        self.pinned_cert_fingerprint = pinned_cert_fingerprint

        self.event_buffer = event_buffer
        self.screen_time_mgr = screen_time_mgr
        self.app_controller = app_controller
        self.domain_engine = domain_engine
        self.db = db

        self._http_client = http_client
        self.current_policy_version: int = 1
        self.active_policy: Dict[str, Any] = {}
        self.ws_connected: bool = False
        self._running: bool = False

    def verify_cert_fingerprint(self, cert_der: bytes) -> bool:
        """Verifies server certificate SHA-256 fingerprint against pinned value."""
        if not self.pinned_cert_fingerprint:
            return True
        import hashlib
        computed = hashlib.sha256(cert_der).hexdigest().lower()
        expected = self.pinned_cert_fingerprint.lower().replace(":", "").replace(" ", "")
        return computed == expected

    async def get_http_client(self) -> httpx.AsyncClient:
        """Returns shared or new async httpx client supporting custom CA/cert pinning."""
        if self._http_client is not None and not self._http_client.is_closed:
            return self._http_client
        ca_cert = os.getenv("OGK_CA_CERT") or "certs/server.crt"
        if os.path.exists(ca_cert):
            verify: Any = ca_cert
        elif os.getenv("OGK_INSECURE_TLS") == "1":
            verify = False
        else:
            verify = True
        self._http_client = httpx.AsyncClient(timeout=10.0, verify=verify)
        return self._http_client

    async def enroll(self, pairing_code: str, device_fingerprint: str, windows_user_sid: str) -> Dict[str, Any]:
        """
        Executes device enrollment using pairing code (FR-LC-01).
        Stores credentials and signed initial policy.
        """
        client = await self.get_http_client()
        url = f"{self.server_url}/api/v1/enroll"
        payload = {
            "pairing_code": pairing_code,
            "device_fingerprint": device_fingerprint,
            "windows_user_sid": windows_user_sid,
        }

        resp = await client.post(url, json=payload)
        if resp.status_code != 200:
            raise RuntimeError(f"Enrollment failed ({resp.status_code}): {resp.text}")

        data = resp.json()
        self.device_id = data["device_id"]
        self.child_id = data["child_id"]
        self.access_token = data["access_token"]
        self.refresh_token = data["refresh_token"]

        # Process initial signed policy
        policy = data.get("policy", {})
        if policy:
            self._apply_policy(policy)

        logger.info("Device successfully enrolled! Device ID: %s, Child ID: %s", self.device_id, self.child_id)
        return data

    async def refresh_access_token(self) -> bool:
        """Refreshes expired access_token using refresh_token."""
        if not self.refresh_token:
            return False

        client = await self.get_http_client()
        url = f"{self.server_url}/api/v1/auth/device/refresh"
        try:
            resp = await client.post(url, json={
                "device_id": self.device_id,
                "refresh_token": self.refresh_token,
            })
            if resp.status_code == 200:
                data = resp.json()
                self.access_token = data["access_token"]
                logger.debug("Access token refreshed successfully.")
                return True
            else:
                logger.warning("Token refresh rejected: %s", resp.text)
                return False
        except Exception as e:
            logger.error("Token refresh network error: %s", e)
            return False

    async def send_heartbeat(self) -> Dict[str, Any]:
        """
        Sends 60s heartbeat to server (FR-LC-02).
        Computes clock drift and processes pending commands.
        """
        client = await self.get_http_client()
        url = f"{self.server_url}/api/v1/heartbeat"

        used_sec = self.screen_time_mgr.used_total_sec if self.screen_time_mgr else 0
        mono_sec = self.screen_time_mgr.last_monotonic if self.screen_time_mgr else 0.0

        payload = {
            "device_id": self.device_id,
            "child_id": self.child_id,
            "used_sec": used_sec,
            "local_utc": datetime.now(timezone.utc).isoformat(),
            "monotonic_sec": mono_sec,
            "policy_version": self.current_policy_version,
        }
        headers = {"Authorization": f"Bearer {self.access_token}"}

        resp = await client.post(url, json=payload, headers=headers)
        if resp.status_code == 401:
            # Token expired, try refreshing
            if await self.refresh_access_token():
                headers = {"Authorization": f"Bearer {self.access_token}"}
                resp = await client.post(url, json=payload, headers=headers)

        if resp.status_code != 200:
            raise RuntimeError(f"Heartbeat failed ({resp.status_code}): {resp.text}")

        data = resp.json()
        server_utc = data.get("server_utc")
        if server_utc and self.screen_time_mgr:
            self.screen_time_mgr.verify_clock_drift(server_utc)

        # Check policy version mismatch
        latest_ver = data.get("latest_policy_version", self.current_policy_version)
        if latest_ver > self.current_policy_version:
            logger.info("Newer policy version detected (%d > %d). Syncing policy.", latest_ver, self.current_policy_version)
            await self.fetch_and_apply_policy()

        # Execute any pending commands
        pending_cmds = data.get("pending_commands", [])
        for cmd in pending_cmds:
            await self._execute_command(cmd)

        return data

    async def upload_event_batch(self) -> int:
        """
        Uploads pending events from event_buffer to server (FR-LC-04, FR-F3-01).
        Uses idempotency_key to prevent duplicate ingestion.
        Returns count of successfully synced events.
        """
        if not self.event_buffer:
            return 0

        batch = self.event_buffer.get_pending_batch(limit=200)
        if not batch:
            return 0

        client = await self.get_http_client()
        url = f"{self.server_url}/api/v1/events/batch"
        headers = {"Authorization": f"Bearer {self.access_token}"}

        # Filter fields strictly
        clean_events = []
        for item in batch:
            clean_events.append({
                "idempotency_key": item["idempotency_key"],
                "ts": item["ts"],
                "device_id": item["device_id"],
                "child_id": item["child_id"],
                "type": item["type"],
                "subject": item["subject"],
                "duration_sec": item.get("duration_sec", 0),
                "policy_id": item.get("policy_id", "default_policy"),
            })

        resp = await client.post(url, json={"events": clean_events}, headers=headers)
        if resp.status_code == 401:
            if await self.refresh_access_token():
                headers = {"Authorization": f"Bearer {self.access_token}"}
                resp = await client.post(url, json={"events": clean_events}, headers=headers)

        if resp.status_code == 200:
            # Mark uploaded events as synced
            keys = [e["idempotency_key"] for e in clean_events]
            self.event_buffer.mark_synced(keys)
            logger.info("Successfully synced %d events to server.", len(keys))
            return len(keys)
        else:
            logger.warning("Event batch upload failed (%d): %s", resp.status_code, resp.text)
            return 0

    async def fetch_and_apply_policy(self) -> bool:
        """Fetches signed policy from GET /api/v1/policy and verifies HMAC signature."""
        client = await self.get_http_client()
        url = f"{self.server_url}/api/v1/policy"
        headers = {"Authorization": f"Bearer {self.access_token}"}

        resp = await client.get(url, headers=headers)
        if resp.status_code == 401:
            if await self.refresh_access_token():
                headers = {"Authorization": f"Bearer {self.access_token}"}
                resp = await client.get(url, headers=headers)

        if resp.status_code != 200:
            logger.error("Failed to fetch policy (%d): %s", resp.status_code, resp.text)
            return False

        policy = resp.json()
        return self._apply_policy(policy)

    def _apply_policy(self, policy: Dict[str, Any]) -> bool:
        """Verifies policy signature and applies rules to runtime engines."""
        # 1. Verify signature
        is_valid, reason = verify_policy(policy, self.device_secret)
        if not is_valid:
            logger.error("Policy rejected! Reason: %s", reason)
            return False

        self.active_policy = policy
        self.current_policy_version = policy.get("version", self.current_policy_version)

        # 2. Persist in local DB cache
        if self.db:
            sig = policy.get("signature", "")
            policy_json_str = json.dumps(policy)
            self.db.save_cached_policy(self.current_policy_version, policy_json_str, sig)

        # 3. Apply domain rules to DomainPolicyEngine
        if self.domain_engine:
            dom_rules = policy.get("domain_rules_json")
            if isinstance(dom_rules, str):
                try:
                    dom_rules = json.loads(dom_rules)
                except Exception:
                    dom_rules = []
            self.domain_engine.load_policy(dom_rules or [])

        logger.info("Successfully applied policy v%d", self.current_policy_version)
        return True

    async def _execute_command(self, cmd_envelope: Dict[str, Any]) -> None:
        """Executes an urgent command envelope (FR-LC-03, Section 5.2)."""
        cmd_type = cmd_envelope.get("command")
        params = cmd_envelope.get("params", {})
        cmd_id = cmd_envelope.get("command_id", "")
        logger.info("Executing urgent command: %s (ID: %s)", cmd_type, cmd_id)

        if cmd_type == "LOCK_NOW":
            if self.screen_time_mgr:
                self.screen_time_mgr.set_manual_lock(True)
            if self.app_controller:
                self.app_controller.scan_and_enforce(
                    app_rules=[],
                    is_locked=True,
                    policy_id=str(self.current_policy_version)
                )

        elif cmd_type == "UNLOCK":
            if self.screen_time_mgr:
                self.screen_time_mgr.set_manual_lock(False)

        elif cmd_type == "ADD_TIME_15M":
            bonus_sec = params.get("bonus_seconds", 900)
            if self.screen_time_mgr:
                self.screen_time_mgr.add_bonus_time(bonus_sec)

        elif cmd_type == "PARENT_PAUSE_2H":
            duration = params.get("duration_seconds", 7200)
            if self.screen_time_mgr:
                self.screen_time_mgr.activate_parent_pause(duration)

        elif cmd_type == "PURGE_DATA":
            if self.event_buffer:
                self.event_buffer.purge_local_events()
            if self.screen_time_mgr:
                self.screen_time_mgr.used_total_sec = 0
                self.screen_time_mgr.category_used_sec = {}
                self.screen_time_mgr._persist_state_to_db()

        elif cmd_type == "POLICY_UPDATED":
            await self.fetch_and_apply_policy()

    async def run_websocket_loop(self) -> None:
        """Maintains persistent WebSocket connection for real-time urgent commands (< 5s) with Exponential Backoff + Jitter."""
        ws_url = self.server_url.replace("http://", "ws://").replace("https://", "wss://")
        endpoint = f"{ws_url}/ws/agent/{self.device_id}"
        retry_count = 0
        base_delay = 1.0
        max_delay = 60.0

        while self._running:
            try:
                headers = {"Authorization": f"Bearer {self.access_token}"}
                ssl_context = None
                if endpoint.startswith("wss://"):
                    import ssl
                    ca_cert = os.getenv("OGK_CA_CERT") or "certs/server.crt"
                    if os.path.exists(ca_cert):
                        ssl_context = ssl.create_default_context(cafile=ca_cert)
                    elif os.getenv("OGK_INSECURE_TLS") == "1":
                        ssl_context = ssl.create_default_context()
                        ssl_context.check_hostname = False
                        ssl_context.verify_mode = ssl.CERT_NONE

                async with websockets.connect(endpoint, additional_headers=headers, ssl=ssl_context) as ws:
                    self.ws_connected = True
                    retry_count = 0  # Reset backoff upon successful connection
                    logger.info("Connected to WebSocket Command Hub: %s", endpoint)

                    async for msg_str in ws:
                        try:
                            msg = json.loads(msg_str)
                            if msg.get("msg_type") == "URGENT_COMMAND":
                                await self._execute_command(msg)
                                # Send ACK
                                ack = {
                                    "msg_type": "COMMAND_ACK",
                                    "command_id": msg.get("command_id"),
                                    "status": "EXECUTED",
                                    "executed_at_utc": datetime.now(timezone.utc).isoformat(),
                                }
                                await ws.send(json.dumps(ack))
                        except Exception as parse_err:
                            logger.error("Error processing WebSocket message: %s", parse_err)

            except Exception as e:
                self.ws_connected = False
                retry_count += 1
                import random
                # Exponential backoff: min(60, base * 2^retries) + random jitter [0.1, 1.0]
                delay = min(max_delay, base_delay * (2 ** min(retry_count, 6)))
                jitter = random.uniform(0.1, 1.0)
                total_sleep = delay + jitter
                logger.debug(
                    "WebSocket connection lost: %s. Reconnecting in %.2fs (attempt %d)...",
                    e, total_sleep, retry_count
                )
                await asyncio.sleep(total_sleep)

    async def start(self) -> None:
        """Starts background loops for heartbeat, event sync, and WebSocket."""
        self._running = True
        # Try loading cached policy from SQLite
        if self.db:
            cached = self.db.get_cached_policy()
            if cached and cached.get("policy"):
                self._apply_policy(cached["policy"])

        # Start WebSocket task
        asyncio.create_task(self.run_websocket_loop())

        # Start Heartbeat & Event Sync loop
        asyncio.create_task(self._sync_worker_loop())

    async def _sync_worker_loop(self) -> None:
        """Background loop running heartbeat and event sync every 60s."""
        while self._running:
            try:
                if self.device_id and self.access_token:
                    await self.send_heartbeat()
                    await self.upload_event_batch()
            except Exception as e:
                logger.debug("Periodic sync error: %s", e)
            await asyncio.sleep(60.0)

    def stop(self) -> None:
        """Stops client tasks."""
        self._running = False
