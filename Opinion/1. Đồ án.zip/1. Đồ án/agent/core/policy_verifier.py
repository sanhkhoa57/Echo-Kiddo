"""Policy Verifier for OGK-Agent (FR-F4-03, Section 4.3).
Verifies HMAC-SHA256 signature on local/downloaded policy payload against device secret.
Rejects any tampered policy to protect against local tampering.
"""
import hmac
import hashlib
import json
import logging
from typing import Tuple, Dict, Any, Optional

logger = logging.getLogger("OGK.PolicyVerifier")


class PolicyVerificationError(Exception):
    """Raised when policy verification fails."""
    pass


def canonical_policy_bytes(payload: Dict[str, Any]) -> bytes:
    """Creates deterministic UTF-8 byte representation identical to server implementation."""
    data = {k: v for k, v in payload.items() if k != "signature"}
    canonical_json = json.dumps(data, sort_keys=True, separators=(",", ":"))
    return canonical_json.encode("utf-8")


def calculate_policy_signature(payload: Dict[str, Any], secret: str) -> str:
    """Calculates HMAC-SHA256 digest on canonical representation."""
    data_bytes = canonical_policy_bytes(payload)
    return hmac.new(secret.encode("utf-8"), data_bytes, hashlib.sha256).hexdigest()


def verify_policy(payload: Dict[str, Any], secret: str) -> Tuple[bool, str]:
    """
    Verifies policy integrity and format.
    Returns (True, "OK") or (False, reason).
    """
    if not isinstance(payload, dict):
        return False, "Policy payload must be a JSON object"

    signature = payload.get("signature")
    if not signature:
        return False, "Missing signature in policy payload"

    # Verify HMAC-SHA256 in constant time
    expected_sig = calculate_policy_signature(payload, secret)
    if not hmac.compare_digest(expected_sig, signature):
        logger.warning("Policy signature mismatch! Expected: %s, Received: %s", expected_sig[:8] + "...", signature[:8] + "...")
        return False, "Policy signature mismatch (tampering detected)"

    # Basic structural validations
    matrix = payload.get("schedule_matrix")
    if matrix is not None:
        if not isinstance(matrix, str) or len(matrix) != 336 or any(c not in "01" for c in matrix):
            return False, "Invalid schedule_matrix format (must be 336 binary characters)"

    weekday_limit = payload.get("daily_limit_minutes_weekday")
    if weekday_limit is not None and (not isinstance(weekday_limit, int) or weekday_limit < 0):
        return False, "daily_limit_minutes_weekday must be non-negative integer"

    weekend_limit = payload.get("daily_limit_minutes_weekend")
    if weekend_limit is not None and (not isinstance(weekend_limit, int) or weekend_limit < 0):
        return False, "daily_limit_minutes_weekend must be non-negative integer"

    return True, "OK"
