"""Local SQLite Cache for OGK-Agent (Section 4.2 of technical-specification.md).

Manages C:\\ProgramData\\OGK\\agent.db with 4 core tables:
1. cached_policy (offline policy enforcement)
2. event_queue (offline resilient event store)
3. daily_usage_state (monotonic screen-time & anti-clock tampering)
4. system_snapshots (safe system state capture for 100% clean rollback)
"""
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Generator

DEFAULT_AGENT_DATA_DIR = Path(os.getenv("PROGRAMDATA", "C:\\ProgramData")) / "OGK"
DEFAULT_AGENT_DB_PATH = DEFAULT_AGENT_DATA_DIR / "agent.db"


class AgentDatabase:
    """Encapsulates local SQLite operations on OGK-Agent."""

    def __init__(self, db_path: Path | str | None = None):
        if db_path is None:
            env_path = os.getenv("OGK_AGENT_DB_PATH")
            self.db_path = Path(env_path) if env_path else DEFAULT_AGENT_DB_PATH
        else:
            self.db_path = Path(db_path)

        # Ensure directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.init_db()

    @contextmanager
    def get_connection(self) -> Generator[sqlite3.Connection, None, None]:
        """Provides a connection with required PRAGMAs configured."""
        conn = sqlite3.connect(
            str(self.db_path),
            timeout=5.0,
            check_same_thread=False
        )
        conn.row_factory = sqlite3.Row
        try:
            # WAL mode and concurrency tuning
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA synchronous=NORMAL;")
            conn.execute("PRAGMA foreign_keys=ON;")
            conn.execute("PRAGMA busy_timeout=5000;")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def init_db(self) -> None:
        """Initializes the 4 tables defined in technical-specification.md Section 4.2."""
        with self.get_connection() as conn:
            # 1. cached_policy table (single active row id=1)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS cached_policy (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    version INTEGER NOT NULL,
                    policy_json TEXT NOT NULL,
                    signature TEXT NOT NULL,
                    fetched_at_utc TEXT NOT NULL
                );
            """)

            # 2. event_queue table (offline storage with idempotency key)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS event_queue (
                    idempotency_key TEXT PRIMARY KEY,
                    ts TEXT NOT NULL,
                    device_id TEXT NOT NULL,
                    child_id TEXT NOT NULL,
                    type TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    duration_sec INTEGER NOT NULL DEFAULT 0,
                    policy_id TEXT NOT NULL,
                    synced INTEGER NOT NULL DEFAULT 0,
                    created_at_utc TEXT NOT NULL
                );
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_event_queue_synced ON event_queue(synced);
            """)

            # 3. daily_usage_state table (monotonic clock tracking & anti-tampering)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS daily_usage_state (
                    date_local TEXT PRIMARY KEY,
                    used_total_sec INTEGER NOT NULL DEFAULT 0,
                    category_used_json TEXT NOT NULL DEFAULT '{}',
                    last_monotonic_sec REAL NOT NULL DEFAULT 0.0,
                    last_wall_clock_utc TEXT NOT NULL
                );
            """)

            # 4. system_snapshots table (network DNS and browser registry snapshots)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS system_snapshots (
                    snapshot_type TEXT PRIMARY KEY,
                    data_json TEXT NOT NULL,
                    captured_at_utc TEXT NOT NULL,
                    restored_at_utc TEXT
                );
            """)

    # --- 1. Policy Cache Methods ---
    def save_cached_policy(self, version: int, policy_json: str, signature: str, fetched_at_utc: str | None = None) -> None:
        fetched_at = fetched_at_utc or datetime.now(timezone.utc).isoformat()
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO cached_policy (id, version, policy_json, signature, fetched_at_utc)
                VALUES (1, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    version = excluded.version,
                    policy_json = excluded.policy_json,
                    signature = excluded.signature,
                    fetched_at_utc = excluded.fetched_at_utc;
            """, (version, policy_json, signature, fetched_at))

    def get_cached_policy(self) -> dict[str, Any] | None:
        with self.get_connection() as conn:
            row = conn.execute("SELECT * FROM cached_policy WHERE id = 1;").fetchone()
            if row:
                return dict(row)
            return None

    # --- 2. Event Queue Methods ---
    def enqueue_event(
        self,
        idempotency_key: str,
        ts: str,
        device_id: str,
        child_id: str,
        type_: str,
        subject: str,
        duration_sec: int,
        policy_id: str,
    ) -> bool:
        created_at = datetime.now(timezone.utc).isoformat()
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT OR IGNORE INTO event_queue (
                    idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id, synced, created_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?);
            """, (idempotency_key, ts, device_id, child_id, type_, subject, duration_sec, policy_id, created_at))
            return cursor.rowcount > 0

    def get_unsynced_events(self, limit: int = 200) -> list[dict[str, Any]]:
        with self.get_connection() as conn:
            rows = conn.execute("""
                SELECT idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id
                FROM event_queue
                WHERE synced = 0
                ORDER BY ts ASC
                LIMIT ?;
            """, (limit,)).fetchall()
            return [dict(r) for r in rows]

    def mark_events_synced(self, idempotency_keys: list[str]) -> int:
        if not idempotency_keys:
            return 0
        with self.get_connection() as conn:
            placeholders = ",".join("?" for _ in idempotency_keys)
            cursor = conn.execute(f"""
                UPDATE event_queue
                SET synced = 1
                WHERE idempotency_key IN ({placeholders});
            """, idempotency_keys)
            return cursor.rowcount

    def purge_all_events(self) -> int:
        """Purge all events for privacy wipe (PURGE_DATA command)."""
        with self.get_connection() as conn:
            cursor = conn.execute("DELETE FROM event_queue;")
            return cursor.rowcount

    # --- 3. Daily Usage State Methods ---
    def get_daily_usage(self, date_local: str) -> dict[str, Any] | None:
        with self.get_connection() as conn:
            row = conn.execute("SELECT * FROM daily_usage_state WHERE date_local = ?;", (date_local,)).fetchone()
            if row:
                return dict(row)
            return None

    def save_daily_usage(
        self,
        date_local: str,
        used_total_sec: int,
        category_used_json: str,
        last_monotonic_sec: float,
        last_wall_clock_utc: str | None = None
    ) -> None:
        wall_clock = last_wall_clock_utc or datetime.now(timezone.utc).isoformat()
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO daily_usage_state (
                    date_local, used_total_sec, category_used_json, last_monotonic_sec, last_wall_clock_utc
                ) VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(date_local) DO UPDATE SET
                    used_total_sec = excluded.used_total_sec,
                    category_used_json = excluded.category_used_json,
                    last_monotonic_sec = excluded.last_monotonic_sec,
                    last_wall_clock_utc = excluded.last_wall_clock_utc;
            """, (date_local, used_total_sec, category_used_json, last_monotonic_sec, wall_clock))

    # --- 4. System Snapshot Methods ---
    def save_snapshot(self, snapshot_type: str, data_json: str, captured_at_utc: str | None = None) -> None:
        captured_at = captured_at_utc or datetime.now(timezone.utc).isoformat()
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO system_snapshots (snapshot_type, data_json, captured_at_utc, restored_at_utc)
                VALUES (?, ?, ?, NULL)
                ON CONFLICT(snapshot_type) DO UPDATE SET
                    data_json = excluded.data_json,
                    captured_at_utc = excluded.captured_at_utc,
                    restored_at_utc = NULL;
            """, (snapshot_type, data_json, captured_at))

    def get_snapshot(self, snapshot_type: str) -> dict[str, Any] | None:
        with self.get_connection() as conn:
            row = conn.execute("SELECT * FROM system_snapshots WHERE snapshot_type = ?;", (snapshot_type,)).fetchone()
            if row:
                return dict(row)
            return None

    def mark_snapshot_restored(self, snapshot_type: str, restored_at_utc: str | None = None) -> bool:
        restored_at = restored_at_utc or datetime.now(timezone.utc).isoformat()
        with self.get_connection() as conn:
            cursor = conn.execute("""
                UPDATE system_snapshots
                SET restored_at_utc = ?
                WHERE snapshot_type = ?;
            """, (restored_at, snapshot_type))
            return cursor.rowcount > 0
