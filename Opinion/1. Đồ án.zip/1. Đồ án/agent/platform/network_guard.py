"""Network DNS Guard for OGK-Agent (FR-F2-07, M3).
Snapshots adapter DNS configuration into agent.db before locking to 127.0.0.1.
Monitors tampering, flushes Windows resolver cache, and restores original DNS cleanly.
"""
import ctypes
import json
import logging
import subprocess
import sys
from typing import List, Dict, Any, Optional

logger = logging.getLogger("OGK.NetworkGuard")

_IS_WINDOWS = sys.platform == "win32"


def flush_dns_cache() -> bool:
    """Calls Windows dnsapi.dll DnsFlushResolverCache to immediately invalidate DNS cache."""
    if _IS_WINDOWS:
        try:
            dnsapi = ctypes.windll.dnsapi
            result = dnsapi.DnsFlushResolverCache()
            logger.debug("DnsFlushResolverCache returned: %d", result)
            return result == 1
        except Exception as e:
            logger.debug("Failed to call DnsFlushResolverCache via ctypes: %s", e)

    # Fallback to ipconfig /flushdns
    try:
        subprocess.run(["ipconfig", "/flushdns"], capture_output=True, check=False)
        return True
    except Exception:
        return False


class NetworkDnsGuard:
    """Safely manages DNS lock on active network interfaces with snapshot rollback."""

    def __init__(self, db=None):
        self.db = db

    def capture_and_save_snapshot(self) -> List[Dict[str, Any]]:
        """
        Captures current DNS configuration of all IPv4 adapters and saves to agent.db.
        Returns the snapshot list.
        """
        snapshot = self._get_current_adapters_config()
        if self.db:
            self.db.save_snapshot("NETWORK_DNS", json.dumps(snapshot))
            logger.info("Saved NETWORK_DNS snapshot with %d interfaces", len(snapshot))
        return snapshot

    def _get_current_adapters_config(self) -> List[Dict[str, Any]]:
        """Extracts adapter DNS configuration via netsh or powershell."""
        adapters = []
        if not _IS_WINDOWS:
            return [{"name": "Mock-Adapter", "dhcp": True, "dns": []}]

        try:
            # Query IPv4 interfaces using netsh
            output = subprocess.check_output(
                ["netsh", "interface", "ipv4", "show", "dnsservers"],
                text=True, stderr=subprocess.DEVNULL
            )
            current_name = None
            current_dhcp = True
            current_dns = []

            for line in output.splitlines():
                line = line.strip()
                if "Configuration for interface" in line:
                    if current_name:
                        adapters.append({"name": current_name, "dhcp": current_dhcp, "dns": current_dns})
                    # Extract interface name inside quotes
                    parts = line.split('"')
                    current_name = parts[1] if len(parts) > 1 else line
                    current_dhcp = True
                    current_dns = []
                elif "DHCP" in line or "configured by DHCP" in line:
                    current_dhcp = True
                elif "Statically Configured" in line:
                    current_dhcp = False
                elif "DNS servers" in line:
                    tokens = line.split(":")
                    if len(tokens) > 1:
                        ip = tokens[1].strip()
                        if ip and ip != "None":
                            current_dns.append(ip)
                elif line and line[0].isdigit() and "." in line:
                    current_dns.append(line.strip())

            if current_name:
                adapters.append({"name": current_name, "dhcp": current_dhcp, "dns": current_dns})

        except Exception as e:
            logger.debug("Failed to query netsh for DNS config: %s", e)

        return adapters

    def lock_dns_to_loopback(self, port_conflict: bool = False) -> bool:
        """
        Sets DNS server on all active physical interfaces to 127.0.0.1 and flushes cache.
        Adheres to EX-01: Does NOT lock if port 53 is in conflict to avoid internet outage.
        """
        if port_conflict:
            logger.warning("EX-01: Port 53 conflict detected. Aborting DNS lock to 127.0.0.1 to prevent network outage.")
            return False

        if not _IS_WINDOWS:
            logger.debug("Non-windows environment: skipping netsh DNS lock.")
            return True

        adapters = self._get_current_adapters_config()
        for adapter in adapters:
            name = adapter.get("name")
            if not name or "loopback" in name.lower() or "pseudo" in name.lower():
                continue
            try:
                # Set primary DNS to 127.0.0.1
                subprocess.run(
                    ["netsh", "interface", "ipv4", "set", "dns", f"name={name}", "static", "127.0.0.1"],
                    capture_output=True, check=False
                )
                logger.info("Locked adapter '%s' DNS to 127.0.0.1", name)
            except Exception as e:
                logger.warning("Failed to lock DNS on '%s': %s", name, e)

        flush_dns_cache()
        return True

    def check_and_enforce_anti_tamper(self) -> bool:
        """
        Detects if DNS was altered (e.g. to 8.8.8.8) and reapplies 127.0.0.1.
        Returns True if tampering was detected and corrected.
        """
        if not _IS_WINDOWS:
            return False

        tampered = False
        adapters = self._get_current_adapters_config()
        for adapter in adapters:
            name = adapter.get("name", "")
            if not name or "loopback" in name.lower() or "pseudo" in name.lower():
                continue

            dns_list = adapter.get("dns", [])
            # If adapter has DNS configured but 127.0.0.1 is not first, it's tampered
            if dns_list and dns_list[0] != "127.0.0.1":
                logger.warning("DNS tampering detected on '%s'! Current: %s. Resetting to 127.0.0.1", name, dns_list)
                try:
                    subprocess.run(
                        ["netsh", "interface", "ipv4", "set", "dns", f"name={name}", "static", "127.0.0.1"],
                        capture_output=True, check=False
                    )
                    tampered = True
                except Exception as e:
                    logger.error("Failed to reset DNS on '%s': %s", name, e)

        if tampered:
            flush_dns_cache()

        return tampered

    def restore_original_dns(self) -> bool:
        """Restores network adapters to their initial state from the snapshot."""
        if not self.db:
            logger.error("No database reference to restore NETWORK_DNS snapshot")
            return False

        row = self.db.get_snapshot("NETWORK_DNS")
        if not row or not row.get("data_json"):
            logger.warning("No NETWORK_DNS snapshot found in agent.db")
            return False

        try:
            snapshot = json.loads(row["data_json"])
        except Exception:
            snapshot = []

        if not _IS_WINDOWS:
            logger.info("Non-windows environment: mock restoring DNS snapshot")
            self.db.mark_snapshot_restored("NETWORK_DNS")
            return True

        success = True
        for adapter in snapshot:
            name = adapter.get("name")
            if not name:
                continue
            is_dhcp = adapter.get("dhcp", True)
            dns_servers = adapter.get("dns", [])

            try:
                if is_dhcp or not dns_servers:
                    subprocess.run(
                        ["netsh", "interface", "ipv4", "set", "dns", f"name={name}", "dhcp"],
                        capture_output=True, check=False
                    )
                    logger.info("Restored '%s' to DHCP DNS", name)
                else:
                    # Restore static DNS
                    primary = dns_servers[0]
                    subprocess.run(
                        ["netsh", "interface", "ipv4", "set", "dns", f"name={name}", "static", primary],
                        capture_output=True, check=False
                    )
                    for sec in dns_servers[1:]:
                        subprocess.run(
                            ["netsh", "interface", "ipv4", "add", "dns", f"name={name}", sec, "index=2"],
                            capture_output=True, check=False
                        )
                    logger.info("Restored '%s' to static DNS: %s", name, dns_servers)
            except Exception as e:
                logger.error("Failed to restore DNS for '%s': %s", name, e)
                success = False

        flush_dns_cache()
        if success and self.db:
            self.db.mark_snapshot_restored("NETWORK_DNS")
        return success
