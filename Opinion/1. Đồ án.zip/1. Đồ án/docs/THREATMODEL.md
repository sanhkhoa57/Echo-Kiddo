# Mô Hình Mối Đe Dọa (STRIDE Threat Model)

> **Dự án OGK (Open Guardian for Kids) — Phân tích mối đe dọa bảo mật theo chuẩn STRIDE**

---

## 1. Phương Pháp Luận STRIDE
Hệ thống OGK áp dụng mô hình phân loại STRIDE của Microsoft:
- **S**poofing (Giả mạo danh tính)
- **T**ampering (Sửa đổi dữ liệu trái phép)
- **R**epudiation (Chối bỏ trách nhiệm)
- **I**nformation Disclosure (Lộ lọt thông tin)
- **D**enial of Service (Từ chối dịch vụ)
- **E**levation of Privilege (Leo thang đặc quyền)

---

## 2. Bảng Phân Tích 8 Mối Đe Dọa Trọng Tâm

| STT | Mối Đe Dọa (Threat Scenario) | Phân Loại STRIDE | Tác Nhân (Threat Actor) | Mức Độ Rủi Ro | Biện Pháp Đối Phó Trong Kiến Trúc OGK |
|---|---|---|---|---|---|
| **TM-01** | **Chính trẻ là kẻ tấn công: Đổi tên file game thành ứng dụng được phép** (vd: đổi `game.exe` thành `notepad.exe`) | Tampering | Trẻ em (Standard User) | Cao | `AppController` kiểm tra bộ ba: Tên tiến trình + **Mã băm SHA-256** + PE Header `OriginalFileName`. |
| **TM-02** | **Chính trẻ là kẻ tấn công: Lùi đồng hồ hệ thống Windows** để gian lận thời gian chơi | Tampering | Trẻ em (Standard User) | Cao | Dùng đồng hồ đơn điệu `time.monotonic()`, lưu `last_wall_clock_utc` cục bộ và đối chiếu `server_utc` mỗi nhịp tim 60s. |
| **TM-03** | **Chính trẻ là kẻ tấn công: Giả mạo tin nhắn IPC Named Pipe** gửi lệnh `UNLOCK` lên Service | Spoofing / Elevation | Trẻ em (Standard User) | Nghiêm trọng | Service xác thực `actual_sid` từ nhân Windows qua `GetNamedPipeClientProcessId`, yêu cầu `ChallengeToken` và dùng `hmac.compare_digest`. |
| **TM-04** | **Chính trẻ là kẻ tấn công: Tắt tiến trình khay hệ thống (Kill Task)** qua Task Manager | Denial of Service | Trẻ em (Standard User) | Trung bình | `SessionAgentLauncher` quét mỗi 3s và tự động khởi chạy lại `OGK-Tray`; nếu không thể hiện sau 3 lần thì chuyển sang `UNPROTECTED_HALT` để minh bạch. |
| **TM-05** | **Sản phẩm bị lạm dụng làm phần mềm theo dõi lén (Stalkerware)** | Information Disclosure | Phụ huynh hoặc kẻ xấu mượn máy | Rất nghiêm trọng | **Cấm chế độ ẩn**: Khay hệ thống luôn bật; lược đồ sự kiện chỉ lưu 7 trường tối thiểu; **tuyệt đối không lưu URL/ảnh chụp màn hình/DOM**. |
| **TM-06** | **Tấn công IDOR giữa các phụ huynh**: Truy cập dữ liệu con của gia đình khác qua REST API | Information Disclosure / Elevation | Phụ huynh khác (Attacker) | Rất nghiêm trọng | RBAC chặt chẽ: Mọi truy vấn SQLAlchemy bắt buộc lọc `WHERE parent_id == current_user.id` ở tầng Database. |
| **TM-07** | **Tấn công nghe lén hoặc chèn gói tin giả giữa Agent và Server (Man-in-the-Middle)** | Spoofing / Tampering | Kẻ tấn công mạng LAN | Cao | Toàn bộ giao tiếp chạy qua HTTPS/WSS (TLS 1.2+); Agent thực hiện **Certificate Pinning** ghim dấu vân tay chứng chỉ của Server. |
| **TM-08** | **Tấn công vét cạn mật khẩu phụ huynh (Brute-force Login)** | Spoofing | Kẻ tấn công từ xa | Trung bình - Cao | Mật khẩu băm bằng **Argon2id**; Rate Limit qua `slowapi`; tự động khóa tài khoản 15 phút sau 5 lần nhập sai liên tiếp. |
