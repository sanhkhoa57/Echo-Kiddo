# Nhật Ký & Tuyên Bố Sử Dụng Trợ Lý AI (AI Usage Transparency)

> **Dự án OGK (Open Guardian for Kids) — Minh bạch quá trình sử dụng mô hình trí tuệ nhân tạo**

---

## 1. Mục Đích Sử Dụng
Trợ lý AI được sử dụng trong dự án với vai trò **Pair Programming Partner** & **Kiểm thử kiến trúc**:
- Hỗ trợ xây dựng khung boilerplate mã nguồn theo đúng các đặc tả kiến trúc đã được thẩm định.
- Hỗ trợ rà soát mã nguồn tìm lỗ hổng bảo mật tiềm ẩn (chống Timing Attack, chống IDOR, kiểm soát Session 0 Isolation).
- Tự động hóa sinh bộ dữ liệu phân loại tên miền an toàn mẫu $\ge 200$ mục (tuân thủ nguyên tắc không chứa tên miền người lớn).

---

## 2. Cam Kết Minh Bạch
- Toàn bộ quyết định kiến trúc (ADR-01 đến ADR-03), lược đồ CSDL, quy tắc nghiệp vụ (BR-01 đến BR-08) và logic nghiệp vụ được sinh viên nắm vững 100% để bảo vệ trước hội đồng chấm thi.
- Không sử dụng AI để tạo các nội dung gian lận hoặc vi phạm đạo đức học thuật.
