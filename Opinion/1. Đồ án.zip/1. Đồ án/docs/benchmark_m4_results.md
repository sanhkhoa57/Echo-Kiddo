# BÁO CÁO ĐO LƯỜNG HIỆU NĂNG M4 (OGK PERFORMANCE BENCHMARK)
Thời gian đo: 2026-11-10 17:32:55 UTC
Quy cách: >= 30 mẫu liên tục cho mỗi hạng mục kiểm thử.

## 1. Mức sử dụng Tài nguyên (CPU % & RAM RSS)
| Trạng thái đo | Chỉ số | Min | Mean | Max | p50 | p95 | Tiêu chuẩn cam kết | Đạt |
|---|---|---|---|---|---|---|---|---|
| Rảnh (Idle) | CPU (%) | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | < 1.0% | ✓ |
| Rảnh (Idle) | RAM (MB) | 36.582 | 36.582 | 36.582 | 36.582 | 36.582 | < 100 MB | ✓ |
| Cao điểm (Stress) | CPU (%) | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | < 15.0% | ✓ |
| Cao điểm (Stress) | RAM (MB) | 36.75 | 36.754 | 36.754 | 36.754 | 36.754 | < 120 MB | ✓ |

## 2. Độ trễ Phân giải DNS Proxy (DNS Latency in ms)
| Loại truy vấn | Min (ms) | Mean (ms) | Max (ms) | p50 (ms) | p95 (ms) | Ngưỡng cam kết | Đạt |
|---|---|---|---|---|---|---|---|
| Cache Hit (In-Memory) | 0.645 | 2.966 | 66.779 | 0.76 | 1.052 | < 1.0 ms | ✓ |
| Chặn tên miền (Sinkhole) | 0.715 | 1.372 | 16.137 | 0.842 | 1.155 | < 2.0 ms | ✓ |

## 3. Độ trễ Lệnh Khẩn (Command Dispatch Latency)
| Lệnh khẩn cấp | Min: 0.001 ms | Mean: 0.001 ms | Max: 0.006 ms | p50: 0.001 ms | p95: 0.005 ms | Ngưỡng: < 5000 ms (< 5s) | Đạt: ✓ |